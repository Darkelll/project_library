#include <stdio.h>
#include <sqlite3.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
#include <windows.h>
#include <stdbool.h>  // For 'true' and 'false' 
#include <ctype.h> 
#include <time.h>

#define ENTER 13
#define TAB 9
#define BCKSPC 8

#define STUDENT_MAX 5
#define STAFF_MAX 10
#define MAX_WAITLIST 5
#define RESERVATION_EXPIRY_DAYS 3
#define FINE_PER_DAY 5

static int callback(void *NotUsed, int argc, char **argv, char **azColName) {
   int i;
   for(i = 0; i<argc; i++) {
      printf("%s = %s\n", azColName[i], argv[i] ? argv[i] : "NULL");
   }
   printf("\n");
   return 0;    
}

struct guest {
    char fullname[50];
    char id[50];
    char password[50];
    char username[50];
};

struct staff {
    char fullname[50];
    char id[50];
    char password[50];
    char username[50];
};

typedef struct { 
    int ID; 
    char title[50]; 
    char author[50]; 
    bool borrowed;  
    int waitlist[MAX_WAITLIST]; // Stores user IDs in waitlist
    int waitlistCount; // Tracks the number of users in waitlist
    time_t reservationExpiry; // Expiration time for the reservation
} Book; 

Book books[STAFF_MAX] = { 
    {1, "Abai", "Mukhtar Auezov", false, {0}, 0}, 
    {2, "AZ i Ia", "Olzhas Suleimenov", false, {0}, 0}, 
    {3, "My name is Qozha", "Berdibek Soqpaqbayev", false, {0}, 0}, 
    {4, "Qara sozder", "Abai Qunanbaiuly", false, {0}, 0}, 
    {5, "Qan men Ter", "Abdizhamil Nurpeisov", false, {0}, 0}, 
    {6, "Qozy Korpesh - Byan Sulu", "Ghabit Musrepov", false, {0}, 0}, 
    {7, "Qyz Zhibek", "Saken Seifullin", false, {0}, 0}, 
    {8, "Ushqan uyia", "Baurzhan Momyshuly", false, {0}, 0}, 
    {9, "Zhabaiy alma", "Sain Muratbekov", false, {0}, 0}, 
    {10, "Zhusan iysy", "Sain Muratbekov", false, {0}, 0} 
};

void availableBooksForStudent() { 
    printf("\nAvailable books:\n"); 
    int availableFound = 0;

    for (int i = 0; i < STUDENT_MAX; i++) { 
        if (!books[i].borrowed) { // Check if the book is not borrowed 
            printf("ID: %d | Title: '%s' | Author: %s\n", books[i].ID, books[i].title, books[i].author); 
            availableFound = 1; 
        } 
    } 

    if (!availableFound) {printf("No available books right now.\n");}
}

void availableBooksForStaff() { 
    printf("\nAvailable books:\n"); 
    int availableFound = 0;

    for (int i = 0; i < STAFF_MAX; i++) { 
        if (!books[i].borrowed) { // Check if the book is not borrowed 
            printf("ID: %d | Title: '%s' | Author: %s\n", books[i].ID, books[i].title, books[i].author); 
            availableFound = 1; 
        } 
    } 

    if (!availableFound) {printf("No available books right now.\n");}
}

void toLowerCase(char *str) {
    for (int i = 0; str[i]; i++) {
        str[i] = tolower(str[i]);
    }
}

void generateReturnReceipt(Book book) {
    char filename[50];
    snprintf(filename, sizeof(filename), "Book_%d_Return_Receipt.txt", book.ID);

    FILE *file = fopen(filename, "w");
    if (file == NULL) {
        perror("Error creating receipt file");
        return;
    }

    char issueDate[20];
    char dueDate[20];
    time_t now = time(NULL);
    struct tm *local = localtime(&now);
    strftime(issueDate, sizeof(issueDate), "%d/%m/%Y", local);

    local->tm_mday += 7;  // Due date is 7 days later
    mktime(local);        // Normalize date
    strftime(dueDate, sizeof(dueDate), "%d/%m/%Y", local);

    fprintf(file, "Receipt for Returned Book\n");
    fprintf(file, "--------------------------\n");
    fprintf(file, "Title: %s\n", book.title);
    fprintf(file, "Book ID: %d\n", book.ID);
    fprintf(file, "Issue Date: %s\n", issueDate);
    fprintf(file, "Due Date: %s\n", dueDate);

    fclose(file);
    printf("Return receipt generated successfully: %s\n", filename);
}

void generateReceipt(Book book) {
    char filename[50];
    snprintf(filename, sizeof(filename), "Book_%d_Receipt.txt", book.ID);

    FILE *file = fopen(filename, "w");
    if (file == NULL) {
        perror("Error creating receipt file");
        return;
    }

    char issueDate[20];
    char dueDate[20];
    time_t now = time(NULL);
    struct tm *local = localtime(&now);
    strftime(issueDate, sizeof(issueDate), "%d/%m/%Y", local);

    local->tm_mday += 7;  // Due date is 7 days later
    mktime(local);        // Normalize date
    strftime(dueDate, sizeof(dueDate), "%d/%m/%Y", local);

    fprintf(file, "Receipt for Borrowed Book\n");
    fprintf(file, "--------------------------\n");
    fprintf(file, "Title: %s\n", book.title);
    fprintf(file, "Book ID: %d\n", book.ID);
    fprintf(file, "Issue Date: %s\n", issueDate);
    fprintf(file, "Due Date: %s\n", dueDate);

    fclose(file);
    printf("Receipt generated successfully: %s\n", filename);
}

void returnBook() { 
    char input[50]; 
    int found = 0;
    printf("\n\nEnter the book's ID or Title you want to return: \n"); 
    getchar(); // Clear newline character
    fgets(input, sizeof(input), stdin);
    input[strcspn(input, "\n")] = '\0'; // Remove newline character

    char lowerInput[50];
    strcpy(lowerInput, input);
    toLowerCase(lowerInput); // Convert input to lowercase

    for (int i = 0; i < STAFF_MAX; i++) { 
        char lowerTitle[50];
        strcpy(lowerTitle, books[i].title);
        toLowerCase(lowerTitle); // Convert title to lowercase

        if (isdigit(lowerInput[0])) { 
            int id = atoi(lowerInput); 
            if (books[i].ID == id && books[i].borrowed) { 
                printf("\nYou have returned the book: '%s' by %s\n", books[i].title, books[i].author); 
                books[i].borrowed = false;
                generateReturnReceipt(books[i]); 
                found = 1; 
                break; 
            } 
        } else if (strcmp(lowerTitle, lowerInput) == 0 && books[i].borrowed) { 
            printf("\nYou have returned the book: '%s' by %s\n", books[i].title, books[i].author); 
            books[i].borrowed = false;
            generateReturnReceipt(books[i]);
            found = 1; 
                break; 
        }
    } 

    if (!found) {printf("\nSorry, this book is either not available or was not borrowed.\n");}
}



void searchBookForStudent() { 
    char input[50]; 
    int found = 0; 
    printf("\n\nEnter the Book ID or Title to search: \n"); 
    getchar(); // Clear newline character from previous input
    fgets(input, sizeof(input), stdin);
    input[strcspn(input, "\n")] = '\0'; // Remove newline character

    char lowerInput[50];
    strcpy(lowerInput, input);
    toLowerCase(lowerInput); // Convert the input to lowercase

    for (int i = 0; i < STUDENT_MAX; i++) { 
        char lowerTitle[50];
        strcpy(lowerTitle, books[i].title);
        toLowerCase(lowerTitle); // Convert the book title to lowercase

        if (isdigit(lowerInput[0])) { 
            int id = atoi(lowerInput); 
            if (books[i].ID == id) { 
                printf("Book found: '%s' by %s\n", books[i].title, books[i].author); 
                found = 1; 
                break; 
            } 
        } else if (strstr(lowerTitle, lowerInput)) { 
            // Use strstr to check if input is a substring of the title
            printf("Book found: '%s' by %s\n", books[i].title, books[i].author); 
            found = 1; 
        }
    } 

    if (!found) { 
        printf("Sorry, the book was not found.\n"); 
    }
}

void searchBookForStaff() { 
    char input[50]; 
    int found = 0; 
    printf("\n\nEnter the Book ID or Title to search: \n"); 
    getchar(); // Clear newline character from previous input
    fgets(input, sizeof(input), stdin);
    input[strcspn(input, "\n")] = '\0'; // Remove newline character

    char lowerInput[50];
    strcpy(lowerInput, input);
    toLowerCase(lowerInput); // Convert the input to lowercase

    for (int i = 0; i < STAFF_MAX; i++) { 
        char lowerTitle[50];
        strcpy(lowerTitle, books[i].title);
        toLowerCase(lowerTitle); // Convert the book title to lowercase

        if (isdigit(lowerInput[0])) { 
            int id = atoi(lowerInput); 
            if (books[i].ID == id) { 
                printf("Book found: '%s' by %s\n", books[i].title, books[i].author); 
                found = 1; 
                break; 
            } 
        } else if (strstr(lowerTitle, lowerInput)) { 
            // Use strstr to check if input is a substring of the title
            printf("Book found: '%s' by %s\n", books[i].title, books[i].author); 
            found = 1; 
        }
    } 

    if (!found) { 
        printf("Sorry, the book was not found.\n"); 
    }
}

void fineManagement() {
    char dueDateStr[20], returnDateStr[20];
    printf("Enter the due date (DD/MM/YYYY): ");
    scanf("%s", dueDateStr);

    printf("Enter the return date (DD/MM/YYYY): ");
    scanf("%s", returnDateStr);

    // Parse due date
    struct tm dueDate = {0};
    sscanf(dueDateStr, "%d/%d/%d", &dueDate.tm_mday, &dueDate.tm_mon, &dueDate.tm_year);
    dueDate.tm_mon -= 1;  // Months are 0-11 in struct tm
    dueDate.tm_year -= 1900; // Years since 1900

    // Parse return date
    struct tm returnDate = {0};
    sscanf(returnDateStr, "%d/%d/%d", &returnDate.tm_mday, &returnDate.tm_mon, &returnDate.tm_year);
    returnDate.tm_mon -= 1;
    returnDate.tm_year -= 1900;

    // Calculate the difference in days
    time_t due = mktime(&dueDate);
    time_t returned = mktime(&returnDate);
    double diffInSeconds = difftime(returned, due);
    int overdueDays = (int)(diffInSeconds / (60 * 60 * 24));

    if (overdueDays > 0) {
        int fine = overdueDays * FINE_PER_DAY;
        printf("This book is %d days overdue. Your fine is: %dRM\n", overdueDays, fine);
    } else {
        printf("Book returned on time. No fine is due.\n");
    }
}

void borrowBookforStudent() { 
    char input[50]; 
    int found = 0; 
    printf("\n\nEnter the book's ID or Title you want to borrow: \n"); 
    getchar(); // Clear newline character
    fgets(input, sizeof(input), stdin);
    input[strcspn(input, "\n")] = '\0'; // Remove newline character

    char lowerInput[50];
    strcpy(lowerInput, input);
    toLowerCase(lowerInput); // Convert input to lowercase

    for (int i = 0; i < STUDENT_MAX; i++) { 
        char lowerTitle[50];
        strcpy(lowerTitle, books[i].title);
        toLowerCase(lowerTitle); // Convert title to lowercase

        if (isdigit(lowerInput[0])) { 
            int id = atoi(lowerInput);  
            if (books[i].ID == id && !books[i].borrowed) { 
                printf("\nYou have borrowed the book: '%s' by %s\n", books[i].title, books[i].author); 
                books[i].borrowed = true;   
                generateReceipt(books[i]);
                found = 1; 
                break; 
            } 
        } else if (strcmp(lowerTitle, lowerInput) == 0 && !books[i].borrowed) { 
            printf("\nYou have borrowed the book: '%s' by %s\n", books[i].title, books[i].author); 
            books[i].borrowed = true;
            generateReceipt(books[i]);
            found = 1; 
            break; 
        }
    } 

    if (!found) {printf("\nSorry, this book is either not available or has already been borrowed.\n");}
}

void borrowBookforStaff() { 
    char input[50]; 
    int found = 0; 
    printf("\n\nEnter the book's ID or Title you want to borrow: \n"); 
    getchar(); // Clear newline character
    fgets(input, sizeof(input), stdin);
    input[strcspn(input, "\n")] = '\0'; // Remove newline character

    char lowerInput[50];
    strcpy(lowerInput, input);
    toLowerCase(lowerInput); // Convert input to lowercase

    for (int i = 0; i < STAFF_MAX; i++) { 
        char lowerTitle[50];
        strcpy(lowerTitle, books[i].title);
        toLowerCase(lowerTitle); // Convert title to lowercase

        if (isdigit(lowerInput[0])) { 
            int id = atoi(lowerInput);  
            if (books[i].ID == id && !books[i].borrowed) { 
                printf("\nYou have borrowed the book: '%s' by %s\n", books[i].title, books[i].author); 
                books[i].borrowed = true;   
                generateReceipt(books[i]);
                found = 1; 
                break; 
            } 
        } else if (strcmp(lowerTitle, lowerInput) == 0 && !books[i].borrowed) { 
            printf("\nYou have borrowed the book: '%s' by %s\n", books[i].title, books[i].author); 
            books[i].borrowed = true;
            generateReceipt(books[i]);
            found = 1; 
            break; 
        }
    } 

    if (!found) {printf("\nSorry, this book is either not available or has already been borrowed.\n");}
}


void reserveBook(int userID) {
    char input[50];
    printf("Enter the book ID or title you want to reserve: ");
    getchar(); // Clear newline character
    fgets(input, sizeof(input), stdin);
    input[strcspn(input, "\n")] = '\0'; 

    for (int i = 0; i < 10; i++) { 
        if (books[i].borrowed) {
            // Check if the input matches the book ID
            if (atoi(input) == books[i].ID || strcasecmp(input, books[i].title) == 0) {
                // Check if the waitlist is full
                if (books[i].waitlistCount < MAX_WAITLIST) {
                    // Add user to waitlist
                    books[i].waitlist[books[i].waitlistCount++] = userID;
                    // Set reservation expiry
                    books[i].reservationExpiry = time(NULL) + (RESERVATION_EXPIRY_DAYS * 24 * 60 * 60); // Expiry in days
                    printf("You have successfully reserved '%s' by %s. You are number %d on the waitlist.\n", books[i].title, books[i].author, books[i].waitlistCount);
                } else {
                    printf("Sorry, the waitlist is full for this book.\n");
                }
                return;
            }
        }
    }
    printf("Book not found or it is not currently borrowed.\n");
}


void checkExpiredReservations() {
    time_t now = time(NULL);
    
    for (int i = 0; i < 10; i++) {
        printf("Checking Book: %s\n", books[i].title);
        printf("  Expiry Time: %s", books[i].reservationExpiry > 0 ? ctime(&books[i].reservationExpiry) : "Not Set\n");
        printf("  Current Time: %s", ctime(&now));
        printf("  Waitlist Count: %d\n", books[i].waitlistCount);

        if (books[i].waitlistCount > 0 && books[i].reservationExpiry < now) {

            printf("Reservation expired! Removing user ID %d from the waitlist.\n", books[i].waitlist[0]);
            
            // Shift waitlist
            for (int j = 1; j < books[i].waitlistCount; j++) {
                books[i].waitlist[j - 1] = books[i].waitlist[j];
            }
            books[i].waitlistCount--;
            books[i].reservationExpiry = 0; // Reset expiry
        }
    }
}



void takeinput(char ch[50]) {
    fgets(ch, 50, stdin);
    ch[strlen(ch) - 1] = 0;
}

void takepassword(char pwd[50]) {
        int i = 0;
        char ch1;
        while (1) {
            ch1 = getch();
            if (ch1 == ENTER || ch1 == TAB) {
                pwd[i] = '\0';
                break;
            } else if (ch1 == BCKSPC && i > 0) {
                i--;
                printf("\b \b");
            } else {
                pwd[i++] = ch1;
                printf("*");
            }
        }
}

void generateStudentUsername(char fullname[50], char id[50], char username[50]) {
    char lastDigit[5] = "";
    size_t i;

    for (i = 0; i < strlen(fullname) && fullname[i] != ' '; i++) {
        username[i] = tolower(fullname[i]);
    }
    username[i] = '\0';

    if (strlen(id) >= 7) {
        strncat(username, id + 7, 3); // Append last digits of ID
    }
}

void generateStaffUsername(char fullname[50], char id[50], char username[50]) {
    char lastDigit[5] = "";
    size_t i;

    for (i = 0; i < strlen(fullname) && fullname[i] != ' '; i++) {
        username[i] = tolower(fullname[i]);
    }
    username[i] = '\0';

    if (strlen(id) >= 7) {
        strncat(username, id + strlen(id) - 3, 3);
    }

    // Append "staff" at the end
    strcat(username, "staff");
}
int check_student_user(sqlite3 *db, struct guest usr) {
    sqlite3_stmt *stmt;
    const char *sql = "SELECT ID, Student_Id, FULLNAME, USERNAME FROM Guests WHERE USERNAME = ? AND PASSWORD = ?;";

    // Prepare the SQL statement
    if (sqlite3_prepare_v2(db, sql, -1, &stmt, NULL) != SQLITE_OK) {
        fprintf(stderr, "Error preparing statement: %s\n", sqlite3_errmsg(db));
        return -1;
    }

    // Bind the parameters
    sqlite3_bind_text(stmt, 1, usr.username, -1, SQLITE_STATIC);
    sqlite3_bind_text(stmt, 2, usr.password, -1, SQLITE_STATIC);

    int userID;

    //int user_found = 0;
    if (sqlite3_step(stmt) == SQLITE_ROW) {
        userID = sqlite3_column_int(stmt, 0);
        const unsigned char *username = sqlite3_column_text(stmt, 3);
        const unsigned char *student_id = sqlite3_column_text(stmt, 1);
        const unsigned char *full_name = sqlite3_column_text(stmt, 2);
        system("cls");
        printf("\n\n\t\t\t== User found! ==\n\n");
        printf("\t|| ID: %d\n", userID);
        printf("\t|| Username: %s\n", username);
        printf("\t|| Student ID: %s\n", student_id);
        printf("\t|| Full Name: %s\n", full_name);
    } else {
        printf("\nUser not found.\n");
        return 1;
    }

    sqlite3_finalize(stmt);
    return userID;
}

int check_staff_user(sqlite3 *db, struct staff stf) {
    sqlite3_stmt *stmt;
    const char *sql = "SELECT ID, Staff_Id, FULLNAME, USERNAME FROM Staff WHERE USERNAME = ? AND PASSWORD = ?;";

    // Prepare the SQL statement
    if (sqlite3_prepare_v2(db, sql, -1, &stmt, NULL) != SQLITE_OK) {
        fprintf(stderr, "Error preparing statement: %s\n", sqlite3_errmsg(db));
        return -1;
    }

    // Bind the parameters
    sqlite3_bind_text(stmt, 1, stf.username, -1, SQLITE_STATIC);
    sqlite3_bind_text(stmt, 2, stf.password, -1, SQLITE_STATIC);

    int userID = -1;

    //int user_found = 0;
    if (sqlite3_step(stmt) == SQLITE_ROW) {
        userID = sqlite3_column_int(stmt, 0);
        const unsigned char *username = sqlite3_column_text(stmt, 3);
        const unsigned char *student_id = sqlite3_column_text(stmt, 1);
        const unsigned char *full_name = sqlite3_column_text(stmt, 2);
        system("cls");
        printf("\n\n\t\t\t== User found! ==\n\n");
        printf("\t|| ID: %d\n", userID);
        printf("\t|| Username: %s\n", username);
        printf("\t|| Student ID: %s\n", student_id);
        printf("\t|| Full Name: %s\n", full_name);
    } else {
        printf("\nUser not found.\n");
        return 1;
    }


    sqlite3_finalize(stmt);
    return userID;
}

int authorazation() {
    int opt;
    while(opt != 1 && opt != 2 && opt != 3) {
        printf("\n\t1. Student\n");
        printf("\t2. Staff\n");
        printf("\t3. Exit\n");
        printf("\tEnter Your choice:\t");
        scanf("%d", &opt);
        if(opt == 1) {
            return 1;
            break;
        }else if(opt == 2) {
            return 2;
            break;
        }else {
            printf("\n\t|| Goodbye! ||\n");
            return 3;
            break;
        }
    }
    
}

int insert_data(sqlite3 *db, struct guest *user, struct staff *staff) {
    char *errMsg = 0;
     char user_password2[50] = {0}; char staff_password2[50] = {0};



    int userID;

    
    printf("\n\t\t\t\t=============================================\n");
    printf("\t\t\t\t||       WELCOME TO LIBRARY APP              ||\n");
    printf("\t\t\t\t=============================================\n\n");


    if(authorazation() == 1) {
        int opt;
        char sql[256];

        system("cls");
        printf("\n\t\t\t\t=============================================\n");
        printf("\t\t\t\t||       LIBRARY APP --- STUDENT              ||\n");
        printf("\t\t\t\t=============================================\n\n");
        printf("\n\t1.Sign up\n");
        printf("\t2.Login\n");
        printf("\t3.Exit\n");
        printf(" \nEnter your choice:\t");
        scanf("%d", &opt);
        fgetc(stdin);
        switch(opt) {
            case 1:
                printf("\n\tEnter Fullname(Name Surname):\t");
                takeinput(user->fullname);
                while(1) {
                    printf("\n\tEnter Password:\t");
                    takepassword(user->password);
                    printf("\n\tConfirm your password:\t");
                    takepassword(user_password2);

                    if (strcmp(user->password, user_password2) == 0) {
                        printf("\n\n\t\t|| Your passwords match! ||\n");
                        break;
                    } else {
                        printf("\nYour passwords do not match!\n");
                    }
                }

                while (1) {
                    printf("\n\tEnter ID:\t");
                    takeinput(user->id);

                    if (strlen(user->id) == 10) {
                        generateStudentUsername(user->fullname, user->id, user->username);
                        printf("\t\t\t|| You have completed registration! ||\n");
                        Sleep(1000);
                        printf("\n\t|| Your Username:\t[ %s ]\n", user->username);
                        Sleep(3000);
                        printf("\n\tRestart the program again to Login\n");
                        Sleep(2000);
                        break;
                    } else {
                        printf("\nPlease input a correct ID (10 characters)!\n");
                    }
                }
                sprintf(sql, "INSERT OR IGNORE INTO Guests(Student_Id, FULLNAME, PASSWORD, USERNAME) VALUES('%s', '%s', '%s', '%s');", user->id, user->fullname, user->password, user->username );
                int rc = sqlite3_exec(db, sql, callback, 0, &errMsg);
                if (rc != SQLITE_OK) {
                    fprintf(stderr, "\nError inserting data: %s\n", errMsg);
                    sqlite3_free(errMsg);
                } else {
                    printf("Student registration successful!\n");
                }
                break;
                break;
            
            case 2:
                char username2[50], pword[50];
                struct guest usr; 
                int action = 1;
                
                while (true) {
                    printf("\n\tEnter your Login:\t");
                    takeinput(usr.username);
                    printf("\n\tEnter your password:\t");
                    takepassword(usr.password);
                    userID = check_student_user(db, usr);
                    if (userID != -1) {
                        break; // Exit loop if login is successful
                    }
                }

                while(action >=1 && action < 8) {
                    printf("\nSelect an action: \n"); 
                    printf("1. Available books\n"); 
                    printf("2. Borrow a book\n"); 
                    printf("3. Return a book\n"); 
                    printf("4. Search a book\n"); 
                    printf("5. Fine management\n");
                    printf("6. Check Reservations\n");
                    printf("7. Reserve Book\n");
                    printf("8. Exit\n"); 
                    printf("Enter action number: "); 
                    scanf("%d", &action); 

                    switch(action) { 
                        case 1: availableBooksForStudent(); break; 
                        case 2: borrowBookforStudent(); break; 
                        case 3: returnBook(); break; 
                        case 4: searchBookForStudent(); break; 
                        case 5: fineManagement(); break;
                        case 6: checkExpiredReservations(); break;
                        case 7: reserveBook(userID); break;
                        case 8: printf("GoodBye!!"); break;
                    default: printf("Invalid selection, try again.\n"); Sleep(2000); break;
                    }
                }
                break;

            case 3:
                printf("\nGoodbye!\n");
                break;
            default:
                printf("\n\t|| Invalid option :( ||\n");
                Sleep(1000);
                break;
        }
    }else if(authorazation() == 2) {
        int opt;
        char sql[256];

        system("cls");
        printf("\n\t\t\t\t=============================================\n");
        printf("\t\t\t\t||       LIBRARY APP --- STAFF              ||\n");
        printf("\t\t\t\t=============================================\n\n");
        printf("\n\t1.Sign up\n");
        printf("\t2.Login\n");
        printf("\t3. Exit\n");
        printf(" \nEnter your choice:\t");
        scanf("%d", &opt);
        fgetc(stdin);
        switch(opt) {
            case 1:
                printf("\n\tEnter Fullname:\t");
                takeinput(staff->fullname);
                while(1) {
                    printf("\n\tEnter Password:\t");
                    takepassword(staff->password);
                    printf("\n\tConfirm your password:\t");
                    takepassword(staff_password2);

                    if (strcmp(staff->password, staff_password2) == 0) {
                        printf("\n\n\t\t|| Your passwords match! ||\n");
                        break;
                    } else {
                        printf("\nYour passwords do not match!\n");
                    }
                }

                while (1) {
                    printf("\n\tEnter ID:\t");
                    takeinput(staff->id);

                    if (strlen(staff->id) == 10) {
                        generateStaffUsername(staff->fullname, staff->id, staff->username);
                        printf("\t\t\t|| You have completed registration! ||\n");
                        Sleep(1000);
                        printf("\n\t|| Your Username:\t[ %s ]\n", staff->username);
                        Sleep(3000);
                        printf("\n\tRestart the program again to Login\n");
                        Sleep(2000);
                        break;
                    } else {
                        printf("\nPlease input a correct ID (10 characters)!\n");
                    }
                }
                sprintf(sql, "INSERT OR IGNORE INTO Staff(Staff_Id, FULLNAME, PASSWORD, USERNAME) VALUES('%s', '%s', '%s', '%s');", staff->id, staff->fullname, staff->password, staff->username );
                
                int rc = sqlite3_exec(db, sql, callback, 0, &errMsg);
                if (rc != SQLITE_OK) {
                    fprintf(stderr, "Error inserting data: %s\n", errMsg);
                    sqlite3_free(errMsg);
                } else {
                    printf("Staff registration successful!\n");
                }
                break;
            
            case 2:
                char username2[50], pword[50];
                struct staff stf; 
                int action = 1;
                
                while (true) {
                    printf("\n\tEnter your Login:\t");
                    takeinput(stf.username);
                    printf("\n\tEnter your password:\t");
                    takepassword(stf.password);
                    userID = check_staff_user(db, stf);
                    if (userID != -1) {
                        break; // Exit loop if login is successful
                    }
                }

                while(action >=1 && action < 8) {
                    printf("\nSelect an action: \n"); 
                    printf("1. Available books\n"); 
                    printf("2. Borrow a book\n"); 
                    printf("3. Return a book\n"); 
                    printf("4. Search a book\n"); 
                    printf("5. Fine management\n");
                    printf("6. Check Reservations\n");
                    printf("7. Reserve Book\n");
                    printf("8. Exit\n"); 
                    printf("Enter action number: "); 
                    scanf("%d", &action); 

                    switch(action) { 
                        case 1: availableBooksForStaff(); break; 
                        case 2: borrowBookforStaff(); break; 
                        case 3: returnBook(); break; 
                        case 4: searchBookForStaff(); break; 
                        case 5: fineManagement(); break;
                        case 6: checkExpiredReservations(); break;
                        case 7: reserveBook(userID); break;
                        case 8: printf("GoodBye!!"); break;
                    default: printf("Invalid selection, try again.\n"); Sleep(2000); break;
                    }
                }
                break;

            case 3:
                printf("\nGoodbye!\n");
                break;
            default:
                printf("\n\t|| Invalid option :( ||\n");
                Sleep(1000);
                break;
        }
    }else {
        printf("");
    }

}

int main() {

    system("color 03");

    sqlite3 *db;
    char *errMsg = 0;
    int rc;

    struct guest user;
    struct staff staff;

    // Open database
    rc = sqlite3_open("users.db", &db);
    if (rc) {
        printf("Can't open database: %s\n", sqlite3_errmsg(db));
        return 1;
    } 

    const char *sql = "CREATE TABLE IF NOT EXISTS Guests(ID INTEGER PRIMARY KEY AUTOINCREMENT, Student_Id TEXT NOT NULL, FULLNAME TEXT NOT NULL, PASSWORD TEXT NOT NULL, USERNAME TEXT NOT NULL);"
                        "CREATE TABLE IF NOT EXISTS Staff(ID INTEGER PRIMARY KEY AUTOINCREMENT, Staff_Id TEXT NOT NULL, FULLNAME TEXT NOT NULL, PASSWORD TEXT NOT NULL, USERNAME TEXT NOT NULL);";

    // Execute SQL statement to create table
    rc = sqlite3_exec(db, sql, 0, 0, &errMsg);
    if (rc != SQLITE_OK) {
        printf("SQL error: %s\n", errMsg);
        sqlite3_free(errMsg);
        sqlite3_close(db);
        return 1;
    }

    //input part
    
    


    insert_data(db, &user, &staff);
    

    // Close the database
    sqlite3_close(db);
    return 0;
}
